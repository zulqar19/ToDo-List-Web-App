// import { createSlice } from "@reduxjs/toolkit";

// export const TodoSlice = createSlice({
//   name: "todos",
//   initialState: { id: 1, title: ['Helo'], count: 0 },
//   reducers: {
//     addTodo: (state, action) => {
//         let title = action.payload
//         state.title = state.title.push(title);
//         state.id = state.id ++;
//         state.count = state.count ++;
//     },
//     clearTodo: (state) => {
//       state.title = [];
//       state.count = 0;
//       state.id = 0;
//     },
//     removeTodo: (state, action) => {
//       const todoId = action.payload;
//       state.title = state.title.filter((todo) => todo.id !== todoId);
//   },
//   },
// });

// export const { addTodo, clearTodo, removeTodo } = TodoSlice.actions;

// export default TodoSlice.reducer;



import { createSlice } from "@reduxjs/toolkit";

const todoSlice = createSlice({
  name: "todos",
  initialState:[],
  reducers: {
    addTodo(state, action) {
      state.push(action.payload);
      // console.log(action.payload);
    },
    clearTodo (state) {
      state.length = 0;
    },
    removeTodo (state, action) {
      state.splice(action.payload,1)
      // const todoId = action.payload;
      // state.count = state.count -1;
      // state.id = state.id -1;
      // console.log(todoId);
      // state.title = state.title.splice(todoId,1)
      // state.title = state.title.filter((todo) => todo.id +1 !== todoId);
      // state.title = state.title;
      // console.log(todoId);
  },
  },
});

// console.log(todoSlice.actions.addTodo());

export const { addTodo, clearTodo, removeTodo } = todoSlice.actions;

export default todoSlice.reducer;
