import AddBox from "./AddBox";
import Footer from "./Footer";

function TodoContainer() {
  return (
    <>
      <AddBox />
      <Footer />
    </>
  );
}

export default TodoContainer;
